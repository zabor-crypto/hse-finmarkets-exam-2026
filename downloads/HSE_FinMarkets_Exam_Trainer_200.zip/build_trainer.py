#!/usr/bin/env python3
"""Build a source-grounded offline finance exam trainer from authored question cards."""
import json, re, hashlib, html, collections, random, pathlib, zipfile
ROOT=pathlib.Path(__file__).resolve().parent
SOURCES={
 'A':('Лекции 1–2: финансовые рынки, регулирование и платежи','Финрынки_и_институты_БАЦРФ_Магистры_1,2.pdf'),
 'B':('Лекция: кредитная система','Финрынки_и_институты_БАЦРФ_Магистры_Кредитная_система.pdf'),
 'C':('Лекции 4–5: эмитенты, инвесторы, страхование, пенсии','Финрынки_и_институты_БАЦРФ_Магистры_4,5.pdf'),
 'D':('Семинар 1: денежный и долговой рынки','БА_ЦРФ_Финрынки_и_институты_Семинар_11(1).pdf'),
 'E':('Семинар 2: ПФИ, валютный и денежный рынки','БА_ЦРФ_Финрынки_и_институты_Семинар_2_ПФИ_реф(1).pdf'),
 'F':('Семинар 3: рынок акций','БА_ЦРФ_Финрынки_и_институты_Семинар_3_акции.pdf'),
}
MAXPAGE={'A':94,'B':21,'C':62,'D':172,'E':133,'F':75}
SINGLE={};DOUBLE={}
for ln in (ROOT/'single_override.txt').read_text().splitlines():
 if not ln.strip():continue
 p=ln.split('|'); assert len(p)==7,p[:1]
 SINGLE[p[0]]=(p[1],p[2:])
for ln in (ROOT/'double_override.txt').read_text().splitlines():
 if not ln.strip():continue
 p=ln.split('|'); assert len(p)==3
 DOUBLE[p[0]]=(int(p[1]),p[2])
CARD=[]; group_count=collections.Counter()
for line in (ROOT/'seeds.txt').read_text(encoding='utf-8').splitlines():
 if not line.strip() or line.startswith('#'):continue
 p=line.split('|'); assert len(p)==13,(len(p),p[:3]); g,page,topic,stem,*rest=p
 pnum=int(page);assert 1<=pnum<=MAXPAGE[g],(g,page,topic)
 original_options=rest[:5]
 mc_expl,open_stem,model,criteria=rest[5:]
 if topic in SINGLE:stem,original_options=SINGLE[topic]
 elif topic in DOUBLE:
  idx,option=DOUBLE[topic];original_options[idx]=option
 opts=[]
 for i,v in enumerate(original_options):
  assert v[0] in '+-',(topic,v)
  opts.append({'label':v[1:].strip(),'isCorrect':v[0]=='+'})
 # Stable per-topic shuffle; never reveal the key by option position.
 random.Random(int(hashlib.sha256(topic.encode('utf-8')).hexdigest()[:8],16)).shuffle(opts)
 assert 1<=sum(o['isCorrect'] for o in opts)<=4,(topic,'correct count')
 assert len({o['label'].casefold() for o in opts})==5,(topic,'duplicate options')
 assert 80<len(open_stem)+len(model),topic
 groups=[[x.strip() for x in c.split('/') if x.strip()] for c in criteria.split(';')]
 assert len(groups)>=2 and all(groups),topic
 gidx=group_count[g];group_count[g]+=1
 src,filename=SOURCES[g]
 card=dict(group=g,subTopic=topic,source=src,filename=filename,page=pnum,stem=stem,options=opts,
   explanation=mc_expl,openPrompt=open_stem,model=model,criteria=groups)
 CARD.append(card)
assert len(CARD)==100,len(CARD)
assert group_count=={'A':20,'B':16,'C':16,'D':20,'E':16,'F':12},group_count
assert len(set(c['subTopic'] for c in CARD))==100
assert len(SINGLE)==24 and all(t in {c['subTopic'] for c in CARD} for t in SINGLE)
assert len(DOUBLE)==24 and all(t in {c['subTopic'] for c in CARD} for t in DOUBLE)
assert not set(SINGLE)&set(DOUBLE)
# Each group is a multiple of 4; each of the 4 blocks receives the same proportion of all 6 sources.
bygroup=collections.defaultdict(int);questions=[]
for card in CARD:
 g=card['group']; offset=bygroup[g]%4;bygroup[g]+=1
 base={k:v for k,v in card.items() if k not in ('stem','options','explanation','openPrompt','model','criteria')}
 questions.append({**base,'id':f'M{len(questions)+1:03d}','type':'mc', 'block':offset+1,
    'prompt':card['stem'],'options':card['options'],'explanation':card['explanation'],
    'model':card['model']})
 questions.append({**base,'id':f'O{len(questions)+1:03d}','type':'open','block':((offset+2)%4)+1,
    'prompt':card['openPrompt'],'model':card['model'],'criteria':card['criteria'],
    'explanation':card['explanation']})
for block in range(1,5):
 qs=[q for q in questions if q['block']==block]
 assert len(qs)==50,(block,len(qs))
 assert collections.Counter(q['type'] for q in qs)=={'mc':25,'open':25}
 assert collections.Counter(q['group'] for q in qs)=={'A':10,'B':8,'C':8,'D':10,'E':8,'F':6}
 assert len({q['subTopic'] for q in qs})==50
# Alternate question types without clustering same source; seeded deterministically.
final=[]
for block in range(1,5):
 mc=[q for q in questions if q['block']==block and q['type']=='mc']
 op=[q for q in questions if q['block']==block and q['type']=='open']
 rng=random.Random(1000+block);rng.shuffle(mc);rng.shuffle(op)
 for j in range(25):
  final += [mc[j],op[j]] if j%2==0 else [op[j],mc[j]]
for i,q in enumerate(final):
 q['number']=(q['block']-1)*50+(i%50)+1
 q['id']=f'Q{q["number"]:03d}'
assert len(set(q['prompt'] for q in final))==200
assert [q['number'] for q in final]==list(range(1,201))
meta={'title':'Финансовые рынки и институты — экзаменационный тренажёр', 'questions':200,
 'blocks':4,'perBlock':50,'choicePerBlock':25,'openPerBlock':25,
 'sourcePolicy':'Проверено на учебных презентациях; собственные формулировки не являются официальными заданиями экзамена',
 'rubric':'Multiple choice: только полностью верный набор; открытые: вывод и существенное обоснование',
 'source_files':list(SOURCES.values()), 'originalBankReference':'19 уникальных вопросов из восстановленного банка промежуточного теста, используются как образцы, не копируются'}
(ROOT/'questions.json').write_text(json.dumps({'meta':meta,'questions':final},ensure_ascii=False,indent=2),encoding='utf-8')
print('BANK VERIFICATION OK',len(final),'questions')
print('Choices',collections.Counter(sum(o['isCorrect'] for o in q['options']) for q in final if q['type']=='mc'))
print('Balance by block:')
for i in range(1,5):
 qq=[q for q in final if q['block']==i];print(i,len(qq),dict(collections.Counter(q['group'] for q in qq)),dict(collections.Counter(q['type'] for q in qq)))
# HTML template is maintained separately and shipped as one standalone HTML embedding exact validated JSON.
template=(ROOT/'template.html').read_text(encoding='utf-8')
payload=json.dumps({'meta':meta,'questions':final},ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
assert template.count('/*__QUESTION_DATA__*/')==1
(ROOT/'index.html').write_text(template.replace('/*__QUESTION_DATA__*/',payload),encoding='utf-8')
readme='''Экзаменационный тренажёр — Финансовые рынки и институты, НИУ ВШЭ

НАЧАЛО: откройте index.html двойным кликом (Chrome / Safari / Edge), подключение к интернету не требуется.
4 независимых варианта по 50 вопросов; 25 выборов (варианты 1–4 из 5) + 25 открытых ответов в каждом.
После КАЖДОГО ответа доступны решение, объяснение и точная ссылка на презентацию/страницу.
Строгий экзаменационный балл по multiple choice: только за полный набор.
В открытых вопросах проверка браузером ОЦЕНОЧНАЯ и основана на ключевых формулировках; синонимы могут быть не распознаны. После просмотра эталона можно изменить отметку самостоятельной оценкой.
Прогресс хранится локально в браузере (localStorage), автоматически. Кнопка «Экспорт» скачивает JSON с результатами.

Разработка: seeds.txt — 100 концептуальных карточек, каждая порождает 1 новый MC и 1 новый открытый вопрос.
Источник: шесть приложенных учебных презентаций, номера слайдов приведены в каждом вопросе.
19 уникальных вопросов промежуточного экзамена из Excel использованы как калибровочный эталон, но не копируются.

GitHub Pages: создайте private/public репозиторий по своему решению и опубликуйте содержимое папки с index.html в корне ветки. Для Pages в настройках выбрать Deploy from a branch. Учтите, что доступный публично Pages сделает вопросы доступными любому человеку.

Проверка содержания: не использовать утверждения о «безрисковом» арбитраже и абсолютной иммунизации как истину, отдельно отмечена инверсия steepener в семинаре 1.
'''
(ROOT/'README.txt').write_text(readme,encoding='utf-8')
with zipfile.ZipFile(ROOT/'HSE_FinMarkets_Exam_Trainer_200.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for nm in ['index.html','questions.json','README.txt','build_trainer.py','template.html','seeds.txt','single_override.txt','double_override.txt']:
  z.write(ROOT/nm,nm)
print('ARTIFACTS',[(f.name,f.stat().st_size) for f in [ROOT/'index.html',ROOT/'questions.json',ROOT/'HSE_FinMarkets_Exam_Trainer_200.zip']])
